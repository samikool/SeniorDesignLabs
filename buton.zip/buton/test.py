import tkinter as tk
import sys 

def activate_button():
    
 print("connected") 

    
def deactivate_button():

   print("disdeconnectd")
    
#def getion_bouton

 

root = tk.Tk()

root.title("Arduino Switch Button")

canvas = tk.Canvas(root, height = 400, width = 400)
canvas.pack()
 
bg_image = tk.PhotoImage(file ="dddd.png")
bg_label = tk.Label(root, image = bg_image)
bg_label.place(x=0, y=0, relwidth=1, relheight =1)

lbl = tk.Label(bg_label)
 
lbl.place(x=0, y=0)

frame = tk.Frame(root, bg= '#80d4ff', bd =5)

frame.place(relx=0.5, rely=0.1, relwidth=0.75, relheight=0.2, anchor = 'n')

button = tk.Button(frame, text="ON", font=20, bg = 'Lightgreen', command= activate_button)
button.place(relx=0.6, relheight=1, relwidth=0.3)

button1 = tk.Button(frame, text="OFF", font=20, bg = 'Lightgreen', command = deactivate_button)
button1.place(relx=0.1, relheight=1, relwidth=0.3)

#display_text = tk.Text(frame, font = 25, bg = 'yellow')
#display_text.place( relwidth =0.5, relheight =1)


#output_label = tk.Label(frame, font = 25, text = msg)
#output_label.place( relwidth = 0.5, relheight=1)






root.mainloop()